--Landfill plus

data:extend({
    {
        type = "bool-setting",
        name = "landfill-plus-breakable-landfill-setting",
        setting_type = "startup",
        default_value = true,
        order = "a"
    },
    {
        type = "bool-setting",
        name = "landfill-plus-unlock-form-start-setting",
        setting_type = "startup",
        default_value = false,
        order = "b"
    },
    {
        type = "int-setting",
        name = "landfill-plus-stack-size",
        setting_type = "startup",
        default_value = 100,
        minimum_value = 1,
        order = "c"
    },
    {
        type = "int-setting",
        name = "landfill-plus-landfill-cost-setting",
        setting_type = "startup",
        default_value = 20,
        order = "d"
    },
    {
        type = "int-setting",
        name = "landfill-plus-landfill-result-setting",
        setting_type = "startup",
        default_value = 1,
        order = "e"
    },
    {
        type = "int-setting",
        name = "landfill-plus-landfill-energy-setting",
        setting_type = "startup",
        default_value = 5,
        order = "f"
    },
    {
        type = "bool-setting",
        name = "landfill-plus-recover-landfill-setting",
        setting_type = "startup",
        default_value = true,
        order = "g"
    },
    {
        type = "bool-setting",
        name = "landfill-plus-save-landfill-mining",
        setting_type = "runtime-per-user",
        default_value = true,
        order = "a"
    },
    --[[{
        type = "bool-setting",
        name = "landfill-plus-only-place-on-shallow-water-setting",
        setting_type = "startup",
        default_value = false 
    },
    {
        type = "bool-setting",
        name = "landfill-near-shore-only",
        setting_type = "startup",
        default_value = false 
    }]]
    {
        type = "string-setting",
        name = "landfill-plus-limiting-mode",
        setting_type = "startup",
        allowed_values = {
            "none",
            "shallow-water-only",
            "near-shore-only"
        },
        default_value = "none",
        order = "h"
    },
    {
        type = "int-setting",
        name = "landfill-plus-shore-only-radius",
        setting_type = "startup",
        default_value = 5,
        minimum_value = 1,
        maximum_value = 15,
        order = "i"
    },
})