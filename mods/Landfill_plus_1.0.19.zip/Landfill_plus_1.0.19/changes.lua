--landfill plus

recover_landfill = {mining_time = 0.1}

local landfill = table.deepcopy(data.raw["tile"]["landfill"])

if settings.startup["landfill-plus-breakable-landfill-setting"].value == true then

data.raw["tile"]["landfill"] = table.deepcopy(data.raw["tile"]["concrete"])
data.raw["tile"]["landfill"].name = "landfill"
data.raw["tile"]["landfill"].order = landfill.order
data.raw["tile"]["landfill"].variants = landfill.variants
data.raw["tile"]["landfill"].build_sound = landfill.build_sound
data.raw["tile"]["landfill"].transition_merges_with_tile = landfill.transition_merges_with_tile
data.raw["tile"]["landfill"].transition_overlay_layer_offset = landfill.transition_overlay_layer_offset
data.raw["tile"]["landfill"].transitions = landfill.transitions
data.raw["tile"]["landfill"].transitions_between_transitions = landfill.transitions_between_transitions
data.raw["tile"]["landfill"].walking_sound = landfill.walking_sound
data.raw["tile"]["landfill"].walking_speed_modifier = landfill.walking_speed_modifier
data.raw["tile"]["landfill"].vehicle_friction_modifier = landfill.vehicle_friction_modifier
data.raw["tile"]["landfill"].trigger_effect = landfill.trigger_effect
data.raw["tile"]["landfill"].layer = 57
data.raw["tile"]["landfill"].layer_group = "ground"
data.raw["tile"]["landfill"].draw_in_water_layer = landfill.draw_in_water_layer
data.raw["tile"]["landfill"].allowed_neighbors = landfill.allowed_neighbors
data.raw["tile"]["landfill"].needs_correction = landfill.needs_correction
data.raw["tile"]["landfill"].map_color = landfill.map_color
data.raw["tile"]["landfill"].minable = recover_landfill
data.raw["tile"]["landfill"].mined_sound = {
  {
    filename = "__core__/sound/landfill-small.ogg"
  },
  {
    filename = "__core__/sound/landfill-small-1.ogg"
  },
  {
    filename = "__core__/sound/landfill-small-2.ogg"
  },
  {
    filename = "__core__/sound/landfill-small-3.ogg"
  },
  {
    filename = "__core__/sound/landfill-small-4.ogg"
  },
  {
    filename = "__core__/sound/landfill-small-5.ogg"
  }
}

else

end

--change recipe

data.raw["recipe"]["landfill"].ingredients = {{"stone",settings.startup["landfill-plus-landfill-cost-setting"].value}}
data.raw["recipe"]["landfill"].results = {{"landfill",settings.startup["landfill-plus-landfill-result-setting"].value}}
data.raw["recipe"]["landfill"].energy_required = settings.startup["landfill-plus-landfill-energy-setting"].value/10

--Only allow landfill on water

if settings.startup["landfill-plus-limiting-mode"].value == "shallow-water-only" then

table.insert(data.raw["tile"]["deepwater"].collision_mask, "layer-50")
table.insert(data.raw["tile"]["deepwater-green"].collision_mask, "layer-50")
table.insert(data.raw["item"]["landfill"].place_as_tile.condition, "layer-50")

else 
end

--indestructible landfill

landfill.name = "unbreakable-landfill"
landfill2 = table.deepcopy(landfill)
landfill2.name = "unbreakable-landfill-2"

data:extend({
  landfill,
  landfill2
})

--unlock landfill form start
if settings.startup["landfill-plus-unlock-form-start-setting"].value == true then
  data.raw["technology"]["landfill"].hidden = true
  data.raw["recipe"]["landfill"].enabled = true
else
end

--landfill stack size
data.raw["item"]["landfill"].stack_size = settings.startup["landfill-plus-stack-size"].value