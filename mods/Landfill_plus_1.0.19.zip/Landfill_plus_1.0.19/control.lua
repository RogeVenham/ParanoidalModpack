--Replace grass with water on existing maps
local function landfill_water_patch(event)
    local surface = game.get_surface(event.surface_index)

    if surface and surface.valid then
        local newTiles = {}

        for _,tile in pairs(event.tiles) do
            local oldTile = tile.old_tile

            if oldTile.name == "landfill" then
                local newTile = surface.get_tile(tile.position.x, tile.position.y)

                if newTile and newTile.valid and newTile.name == "grass-1" then
                    newTiles[#newTiles + 1] = {
                        name = "water",
                        position = tile.position
                    }
                end
            end
        end

        if #newTiles > 0 then
            surface.set_tiles(newTiles)
        end
    end
end

--Give back landfill item on tile mined above

local function recover_landfill_player(event)

    mined_location = event.tiles[1].position
    mined_name = event.tiles[1].old_tile.name

    surface = game.get_surface(event.surface_index)

    tile_name_under = surface.get_tile(mined_location.x, mined_location.y).name


    if settings.startup["landfill-plus-recover-landfill-setting"].value == true then
        if tile_name_under == "water" or tile_name_under == "deepwater" or tile_name_under == "water-green" or tile_name_under == "deepwater-green" or tile_name_under == "unbreakable-landfill" then
            if game.get_player(event.player_index).can_insert("landfill") == true then
                game.get_player(event.player_index).insert({name = "landfill", count = 1})
            else
                surface.create_entity{name = "item-on-ground", stack = {name = "landfill", count = 1}, position = game.get_player(event.player_index).position}
                game.print("Cannot insert landfill. Inventory is full.")
            end
        else
        end
    else
    end

end

--[[local function recover_landfill_robot(event)

    mined_location = event.tiles[1].position
    mined_name = event.tiles[1].old_tile.name

    surface = game.get_surface(event.surface_index)

    tile_name_under = surface.get_tile(mined_location.x, mined_location.y).name


    if settings.startup["landfill-plus-recover-landfill-setting"].value == true then
        if tile_name_under == "water" or tile_name_under == "deepwater" or tile_name_under == "water-green" or tile_name_under == "deepwater-green" then
            --event.robot.insert("landfill")
            game.print(event.robot.can_insert("landfill"))
        else
        end
    else
    end

end]]

local function replace_unbreakable_landfill(event)

    local surface = game.get_surface(event.surface_index)

    if event.tiles[1].old_tile.name == "landfill" then
        surface.set_tiles({{name = "water", position = {event.tiles[1].position.x, event.tiles[1].position.y}}})
    else
    end

    allowed_tile = game.get_surface(event.surface_index).get_tile(event.tiles[1].position.x, event.tiles[1].position.y)

    if allowed_tile.name == "unbreakable-landfill" or allowed_tile.name == "unbreakable-landfill-2" then
        surface.set_tiles({{name = "water", position = {event.tiles[1].position.x, event.tiles[1].position.y}}})
    else
    end
end

--Player can't be killed by removing landfill

local function save_landfill_mining(event)

    if settings.get_player_settings(event.player_index)["landfill-plus-save-landfill-mining"].value == true then

        player_location = game.get_player(event.player_index).position
        local surface = game.get_player(event.player_index).surface

        outer_diameter = 3
        inner_diameter = 1

        if game.get_player(event.player_index).character ~= nil then

            if old_player_location ~= nil then
                if old_player_location ~= player_location then
                    local water_tiles = {}
                    local landfill_tiles = {}
                    local unbreakable_tiles = {}
                
                    for x_offset = -1*outer_diameter,outer_diameter do
                        for y_offset = -1*outer_diameter,outer_diameter do
                            x = math.floor(player_location.x) + x_offset
                            y = math.floor(player_location.y) + y_offset
                        
                            distance = math.max(math.abs(x_offset), math.abs(y_offset))
                        
                            if surface.is_chunk_generated({x/32, y/32}) == true then
                                if distance <= inner_diameter then
                                    if surface.get_tile(x, y).name == "landfill" then
                                        table.insert(unbreakable_tiles, {name = "unbreakable-landfill", position = {x, y}})
                                    else
                                    end
                                else
                                    if surface.get_tile(x, y).name == "unbreakable-landfill" then
                                        table.insert(unbreakable_tiles, {name = "landfill", position = {x, y}})
                                    else
                                    end
                                end
                            else
                            end
                        end
                    end
                
                    --game.surfaces.nauvis.set_tiles(water_tiles)

                    surface.set_tiles(unbreakable_tiles)
                
                else
                end
            else
            end

        else
        end

        old_player_location = player_location

    else
    end

end

local function save_landfill_mining_disabled_patch(event)

    if event.setting == "landfill-plus-save-landfill-mining" and settings.get_player_settings(event.player_index)["landfill-plus-save-landfill-mining"].value == false then
        
        player_location = game.get_player(event.player_index).position
        local surface = game.get_player(event.player_index).surface

        outer_diameter = 3
        inner_diameter = 1

        if game.get_player(event.player_index).character ~= nil then

            if old_player_location ~= nil then
                if old_player_location ~= player_location then
                    local water_tiles = {}
                    local landfill_tiles = {}
                    local unbreakable_tiles = {}
                
                    for x_offset = -1*outer_diameter,outer_diameter do
                        for y_offset = -1*outer_diameter,outer_diameter do
                            x = math.floor(player_location.x) + x_offset
                            y = math.floor(player_location.y) + y_offset
                        
                            distance = math.max(math.abs(x_offset), math.abs(y_offset))
                        
                            if surface.is_chunk_generated({x/32, y/32}) == true then
                                if surface.get_tile(x, y).name == "unbreakable-landfill" then
                                    table.insert(unbreakable_tiles, {name = "landfill", position = {x, y}})
                                else
                                end
                            else
                            end
                        end
                    end
                
                    --game.surfaces.nauvis.set_tiles(water_tiles)

                    surface.set_tiles(unbreakable_tiles)
                
                else
                end
            else
            end

        else
        end

        old_player_location = player_location

    else
    end

end

--Unbreakable landfill under entities

local function unbreakable_entity(event)

    has_tl_ghost_name = false

    if event.created_entity.name == "entity-ghost" then
        if event.created_entity.ghost_name == "tl-dummy-entity" then
            has_tl_ghost_name = true
        else
            has_tl_ghost_name = false
        end
    else
        has_tl_ghost_name = false
    end

    if event.created_entity.name ~= "tl-dummy-entity" then

        if has_tl_ghost_name ~= true then

            local surface = event.created_entity.surface

            local entity_collition_box = event.created_entity.bounding_box
            local entity_position = event.created_entity.position
            
            entity_size = {
                x = math.ceil(entity_collition_box.left_top.x*-1 + entity_collition_box.right_bottom.x),
                y = math.ceil(entity_collition_box.left_top.y*-1 + entity_collition_box.right_bottom.y)
            }
        
            --game.print(entity_size.x.." "..entity_size.y)
        
            local unbreakable_entity_tiles = {}
        
            for x = (-1*entity_size.x/2) + entity_position.x,entity_size.x/2 + entity_position.x - 1 do
                for y = (-1*entity_size.y/2) + entity_position.y,entity_size.y/2 + entity_position.y - 1 do
                    if surface.get_tile(x, y).name == "landfill" then
                        table.insert(unbreakable_entity_tiles, {name = "unbreakable-landfill-2", position = {x, y}})
                    else
                    end
                end
            end
        
            surface.set_tiles(unbreakable_entity_tiles)

        else
        end

    else
    end

end

local function unbreakable_entity_destroyed_player(event)

    local surface = game.get_player(event.player_index).surface

    local entity_collition_box = event.entity.bounding_box
    local entity_position = event.entity.position

    entity_size = {
        x = math.ceil(entity_collition_box.left_top.x*-1 + entity_collition_box.right_bottom.x),
        y = math.ceil(entity_collition_box.left_top.y*-1 + entity_collition_box.right_bottom.y)
    }

    --game.print(entity_size.x.." "..entity_size.y)

    local unbreakable_entity_removal_tiles = {}

    for x = (-1*entity_size.x/2) + entity_position.x,entity_size.x/2 + entity_position.x - 1 do
        for y = (-1*entity_size.y/2) + entity_position.y,entity_size.y/2 + entity_position.y - 1 do
            if surface.get_tile(x, y).name == "unbreakable-landfill-2" then
                table.insert(unbreakable_entity_removal_tiles, {name = "landfill", position = {x, y}})
            else
            end
        end
    end

    surface.set_tiles(unbreakable_entity_removal_tiles)

end

local function unbreakable_entity_destroyed_robot(event)

    local surface = event.robot.surface

    local entity_collition_box = event.entity.bounding_box
    local entity_position = event.entity.position

    entity_size = {
        x = math.ceil(entity_collition_box.left_top.x*-1 + entity_collition_box.right_bottom.x),
        y = math.ceil(entity_collition_box.left_top.y*-1 + entity_collition_box.right_bottom.y)
    }

    --game.print(entity_size.x.." "..entity_size.y)

    local unbreakable_entity_removal_tiles = {}

    for x = (-1*entity_size.x/2) + entity_position.x,entity_size.x/2 + entity_position.x - 1 do
        for y = (-1*entity_size.y/2) + entity_position.y,entity_size.y/2 + entity_position.y - 1 do
            if surface.get_tile(x, y).name == "unbreakable-landfill-2" then
                table.insert(unbreakable_entity_removal_tiles, {name = "landfill", position = {x, y}})
            else
            end
        end
    end

    surface.set_tiles(unbreakable_entity_removal_tiles)

end

local function unbreakable_entity_destroyed_ghost(event)

    local surface = game.get_player(event.player_index).surface

    local entity_collition_box = event.ghost.bounding_box
    local entity_position = event.ghost.position

    entity_size = {
        x = math.ceil(entity_collition_box.left_top.x*-1 + entity_collition_box.right_bottom.x),
        y = math.ceil(entity_collition_box.left_top.y*-1 + entity_collition_box.right_bottom.y)
    }

    --game.print(entity_size.x.." "..entity_size.y)

    local unbreakable_ghost_removal_tiles = {}

    for x = (-1*entity_size.x/2) + entity_position.x,entity_size.x/2 + entity_position.x - 1 do
        for y = (-1*entity_size.y/2) + entity_position.y,entity_size.y/2 + entity_position.y - 1 do
            if surface.get_tile(x, y).name == "unbreakable-landfill-2" then
                table.insert(unbreakable_ghost_removal_tiles, {name = "landfill", position = {x, y}})
            else
            end
        end
    end

    surface.set_tiles(unbreakable_ghost_removal_tiles)

end

local function has_value (tab, val)
    for index, value in ipairs(tab) do
        if value == val then
            return true
        end
    end

    return false
end

local function landfill_near_shore_only(event)

    if event.tile.name == "landfill" then

        local surface = game.get_surface(event.surface_index)

        local radius = settings.startup["landfill-plus-shore-only-radius"].value
    
        local has_shore_in_radius = false
    
        local water_tiles = {"water", "deepwater", "water-green", "deepwater-green", "water-shallow", "water-mud", "landfill", "unbreakable-landfill", "unbreakable-landfill-2"}
        local invalid_tiles = {}
        local item_amount = 0
    
        for _, tiles_placed in pairs(event.tiles) do
            has_shore_in_radius = false
            for shore_x = (radius * -1), radius do
                for shore_y = (radius * -1), radius do
                    if has_value(water_tiles, surface.get_tile(shore_x + tiles_placed.position.x, shore_y + tiles_placed.position.y).name) == false then
                        has_shore_in_radius = true
                    else
                    end
                end
            end
            
            if has_shore_in_radius == false then
                table.insert(invalid_tiles, {name = tiles_placed.old_tile.name, position = {tiles_placed.position.x, tiles_placed.position.y}}) 
                item_amount = item_amount + 1
            else
            end
        end
    
        surface.set_tiles(invalid_tiles)
    
        if item_amount > 0 then 
            game.get_player(event.player_index).insert({name = "landfill", count = item_amount})
        else
        end
    else
    end

end

--Group functions

local function player_mined_tile(event)

    landfill_water_patch(event)
    recover_landfill_player(event)

    if settings.startup["landfill-plus-breakable-landfill-setting"].value == true then
        replace_unbreakable_landfill(event)
    else
    end
end

local function robot_mined_tile(event)
    landfill_water_patch(event)
    if settings.startup["landfill-plus-breakable-landfill-setting"].value == true then
        replace_unbreakable_landfill(event)
    else
    end
end

--Call functions on event

script.on_event(defines.events.on_player_mined_tile, player_mined_tile)
script.on_event(defines.events.on_robot_mined_tile, robot_mined_tile)

if settings.startup["landfill-plus-limiting-mode"].value == "near-shore-only" then 
    script.on_event(defines.events.on_player_built_tile, landfill_near_shore_only)
else
end

if settings.startup["landfill-plus-breakable-landfill-setting"].value == true then
    --script.on_event(defines.events.on_tick, save_landfill_mining)
    script.on_event(defines.events.on_player_changed_position, save_landfill_mining)
    script.on_event(defines.events.on_runtime_mod_setting_changed , save_landfill_mining_disabled_patch)
    script.on_event(defines.events.on_built_entity, unbreakable_entity)
    script.on_event(defines.events.on_player_mined_entity, unbreakable_entity_destroyed_player)
    script.on_event(defines.events.on_robot_mined_entity, unbreakable_entity_destroyed_robot)
    script.on_event(defines.events.on_pre_ghost_deconstructed, unbreakable_entity_destroyed_ghost)
else
end